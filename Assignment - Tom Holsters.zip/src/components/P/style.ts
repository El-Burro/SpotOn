import styled from "styled-components";

export const StyledP = styled.p`
    font-size: 1.8rem;
`;