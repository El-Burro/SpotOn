import styled from "styled-components";

export const StyledSub = styled.summary`
    font-size: 2.4rem
`;