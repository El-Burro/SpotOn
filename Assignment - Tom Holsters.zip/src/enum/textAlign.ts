export enum TextAlignEnum {
    "LEFT" ="left",
    "RIGHT" ="right",
    "CENTER" ="center",
    "JUSTIFY" ="justify"
  }
  