import styled from "styled-components";
import { StyledImagePane } from "../ImagePane/style";

export const StyledEnvironmentPane = styled(StyledImagePane)`
  grid-area: environment;
`;