import styled from "styled-components"
import { StyledImagePane } from "../ImagePane/style"

export const StyledProductImagePane = styled(StyledImagePane)`
	grid-area: product;
`
